# ProfReport - Профессиональная профориентация

**Статус**: ✅ Готово к разработке
**Версия**: 1.0.0

## 🎯 О проекте

ProfReport — платформа для профессиональной профориентации на основе научных методик (RIASEC, Климова, Big Five). Прототип из 8 страниц с SSG/SSR на Astro.

## 🛠️ Технологический стек

Согласно **CORE CONTEXT**:

- **Astro** 4.2+ (SSG/SSR)
- **TypeScript** (strict mode)
- **Tailwind CSS** 3.4+
- **React** 18.2+ (islands для интерактивности)
- **react-hook-form** + **Zod** (валидация форм)
- **Inter font** с `font-display: swap`

## 📁 Структура проекта

```
Front/
├── src/
│   ├── layouts/
│   │   └── BaseLayout.astro       # Базовый layout с SEO, JSON-LD ✅
│   ├── pages/                     # .astro страницы (SSG)
│   │   ├── index.astro            # Главная ✅
│   │   ├── tests.astro            # Выбор тестов ✅
│   │   ├── faq.astro              # FAQ ✅
│   │   ├── about.astro            # О нас ✅
│   │   ├── contacts.astro         # Контакты ✅
│   │   └── test/
│   │       ├── students.astro     # Тест для школьников ✅
│   │       ├── graduates.astro    # Тест для выпускников ✅
│   │       └── adults.astro       # Тест для взрослых ✅
│   ├── components/
│   │   ├── Header.astro           # Навигация ✅
│   │   ├── Footer.astro           # Подвал ✅
│   │   ├── Button.astro           # Кнопки ✅
│   │   └── islands/               # React-компоненты
│   │       ├── FAQAccordion.tsx   # Аккордеон FAQ ✅
│   │       ├── ContactForm.tsx    # Форма контактов ✅
│   │       └── TestFlow.tsx       # Поток тестирования ✅
│   ├── lib/
│   │   ├── schemas.ts             # Zod схемы валидации ✅
│   │   └── utils.ts               # Утилиты, JSON-LD ✅
│   └── styles/
│       └── global.css             # Tailwind + кастом ✅
├── public/
│   ├── favicon.svg                # Favicon ✅
│   ├── robots.txt                 # SEO ✅
│   ├── sitemap.xml                # Sitemap ✅
│   └── og-default.png             # OG изображение (TODO)
├── .env.example                   # Пример переменных ✅
├── astro.config.mjs               # Конфигурация Astro ✅
├── tailwind.config.mjs            # Конфигурация Tailwind ✅
└── tsconfig.json                  # TypeScript конфиг ✅
```

## 🚀 Быстрый старт

### 1. Установка зависимостей

```bash
npm install
```

### 2. Настройка окружения

```bash
cp .env.example .env
```

Отредактируйте `.env`:
```bash
PUBLIC_API_ENDPOINT=https://api.profreport.ru/submit
# PUBLIC_METRIKA_ID=your-metrika-id
# PUBLIC_GTAG_ID=your-gtag-id
```

### 3. Запуск в dev-режиме

```bash
npm run dev
# или
npm start
```

Откроется [http://localhost:4321](http://localhost:4321)

### 4. Сборка для продакшена

```bash
npm run build
npm run preview  # предпросмотр сборки
```

## 📄 Страницы (8 шт.) - ВСЕ ГОТОВЫ ✅

### 1. Главная (`/`)
- Hero-секция с призывом к действию
- Технологии (RIASEC, Климов, Big Five, Ценности)
- Три шага процесса
- Преимущества платформы
- Секции отчета
- CTA-секция
- **JSON-LD**: Organization, HowTo

### 2. Тесты (`/tests`)
- 3 тарифные карточки (школьники 500₽ / выпускники 700₽ / взрослые 900₽)
- Бейдж "Рекомендуем" на центральной
- Описание процесса
- Информация о доставке отчета
- **JSON-LD**: Breadcrumbs

### 3. FAQ (`/faq`)
- React-аккордеон с 10 вопросами
- CTA для обратной связи
- **JSON-LD**: FAQPage, Breadcrumbs

### 4. О нас (`/about`)
- Миссия и цели проекта
- Описание платформы с иконками
- 4 причины выбрать ProfReport
- CTA
- **JSON-LD**: Breadcrumbs

### 5. Контакты (`/contacts`)
- React-форма с валидацией (react-hook-form + Zod)
- Honeypot защита от ботов
- Контактная информация
- Социальные сети
- Toast-уведомление при отправке
- **JSON-LD**: Breadcrumbs

### 6-8. Тесты (Students / Graduates / Adults)
Каждый тест — **полноценный React-island** с:
- **Стартовый экран**: инструкции, чекбокс согласия
- **Прогресс-бар**: текущий вопрос / всего
- **Карточки вопросов**:
  - Likert scale (5 точек)
  - Radio buttons
  - Checkboxes (мультивыбор)
- **Навигацию**: Назад / Далее с валидацией
- **Модальное окно** подтверждения выхода
- **Экран оплаты**: email, согласие с офертой, защита данных
- **Экран успеха**: подтверждение с кнопками

Плейсхолдеры вопросов готовы для замены на реальные.

## 📝 Контракты данных

Согласно **CORE CONTEXT**:

```typescript
type Payload = {
  testType: "school" | "graduate" | "adult";
  email: string;
  tariff: "basic" | "recommended" | "pro";
  answers: Record<string, unknown>;
  consent: true;
};
```

Отправка на `PUBLIC_API_ENDPOINT` как `POST` с JSON.

## 🎨 Дизайн-система (Tailwind)

### Цвета
```js
primary: '#3B82F6'        // bg-primary, text-primary
secondary: '#10B981'      // bg-secondary
background: '#F8FAFC'     // bg-background
surface: '#FFFFFF'        // bg-surface
text-primary: '#1E293B'   // text-text-primary
text-secondary: '#64748B' // text-text-secondary
```

### Компоненты
- **Кнопки**: `<Button variant="primary|secondary|outline|ghost" size="sm|md|lg" />`
- **Контейнер**: `.container-custom` (max-width: 1200px)
- **Скругления**: `rounded-md` (12px), `rounded-lg` (16px)
- **Тени**: `shadow-sm`, `shadow-md`, `shadow-lg`, `shadow-xl`

## ♿ Доступность (WCAG 2.1 AA)

- ✅ Контрастность AA
- ✅ Фокус-стейты (`focus-visible:outline`)
- ✅ Семантическая разметка (`<main>`, `<nav>`, `<header>`, `<footer>`)
- ✅ Touch targets ≥44px
- ✅ ARIA для аккордеонов, модалок, форм
- ✅ Keyboard navigation (Tab, Enter, Escape)

## 🔍 SEO

- ✅ Уникальные `<title>` и `<meta description>` на каждой странице
- ✅ OpenGraph + Twitter Cards
- ✅ JSON-LD:
  - Organization (главная)
  - HowTo (главная)
  - FAQPage (FAQ)
  - BreadcrumbList (все вложенные)
- ✅ `sitemap.xml` со всеми 8 страницами
- ✅ `robots.txt` (разрешает индексацию CSS/JS)
- ✅ `lang="ru"` в `<html>`
- ✅ Canonical URLs

## 🔒 Приватность и безопасность

- ✅ Honeypot в формах (поле `website`)
- ✅ Валидация с Zod (никаких PII в логах)
- ✅ Аналитика с анонимизацией IP
- ✅ Явные чекбоксы согласия
- ✅ Безопасная отправка через fetch с обработкой ошибок

## 🚧 TODO перед запуском

### 1. OG изображение
Создайте `public/og-default.png` (1200x630px):
- Логотип ProfReport
- Текст "Профессиональная профориентация"
- Градиент #3B82F6 → #10B981

### 2. Бэкенд API
Реализуйте endpoint `PUBLIC_API_ENDPOINT`:
```typescript
POST /submit
Body: {
  testType: "school" | "graduate" | "adult",
  email: string,
  tariff: "basic" | "recommended" | "pro",
  answers: Record<string, unknown>,
  consent: true
}
Response: { success: boolean }
```

### 3. Настройка аналитики
Добавьте в `.env`:
```
PUBLIC_METRIKA_ID=your-id
PUBLIC_GTAG_ID=your-id
```

### 4. Реальные вопросы
Замените плейсхолдеры в:
- `src/pages/test/students.astro`
- `src/pages/test/graduates.astro`
- `src/pages/test/adults.astro`

## 📦 Деплой

### Vercel (рекомендуется)
```bash
npm install -g vercel
vercel
```

### Netlify
```bash
npm run build
# Загрузите папку dist/
```

### Другие хостинги
Соберите проект (`npm run build`) и разместите папку `dist/` на любом статическом хостинге.

## 🧪 Тестирование

### Lighthouse
Проверьте производительность:
```bash
npm run build
npm run preview
# Откройте Chrome DevTools > Lighthouse
```

**Цели**: LCP <2.5s, INP <200ms, CLS <0.1

### JSON-LD валидация
Вставьте код страниц в [Google Rich Results Test](https://search.google.com/test/rich-results)

### Доступность
Проверьте с помощью:
- axe DevTools (Chrome extension)
- WAVE (Web Accessibility Evaluation Tool)
- Клавиатурная навигация (Tab, Enter, Esc)

## 📞 Контакты

- Email: info@profreport.ru
- Телефон: +7 (999) 123-45-67

---

## ✅ Чеклист готовности

- [x] 8 страниц созданы
- [x] React-островки работают
- [x] Формы с валидацией Zod
- [x] SEO (meta, JSON-LD, sitemap)
- [x] Доступность (WCAG AA)
- [x] Адаптивность (390px / 1024px / 1440px)
- [x] Tailwind дизайн-система
- [x] TypeScript strict mode
- [ ] OG изображение
- [ ] Бэкенд API
- [ ] Реальные вопросы в тестах
- [ ] Аналитика настроена

**Проект готов к разработке!** Следуйте **CORE CONTEXT** при дальнейших изменениях.
